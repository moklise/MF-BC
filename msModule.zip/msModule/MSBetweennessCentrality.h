//
//  MSBetweennessCentrality.h
//  msModule
//
//  Created by 박민석 on 2015. 11. 4..
//  Copyright © 2015년 박민석. All rights reserved.
//

#ifndef MSBetweennessCentrality_h
#define MSBetweennessCentrality_h

void MSBetweennessCentrality(int** graph, int SIZE, int opt);

#endif /* MSBetweennessCentrality_h */
