//
//  MSinputToMatrix.h
//  msModule
//
//  Created by 박민석 on 2015. 11. 2..
//  Copyright © 2015년 박민석. All rights reserved.
//

#ifndef MSinputToMatrix_h
#define MSinputToMatrix_h
std::pair<int**, int> MSInputToMatrix(int opt);

#endif /* MSinputToMatrix_h */
